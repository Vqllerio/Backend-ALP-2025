package com.wisata.prod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdApplicationTests {

	@Test
	void contextLoads() {
	}

}
